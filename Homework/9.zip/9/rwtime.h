#ifndef rwtime_h
#define rwtime_h

#include "random_walk.h"

void usage(char*);

#endif

