#include "status.h"
#include<unistd.h>

float status::gamma = 1;
float status::delta_t = 1;
float status::kT = 1;

void usage(char* program) {
  fprintf(stderr, "\nProgram Usage:\n%s\n", program);
  fprintf(stderr, "     [ -t  100  ]       times to be run, default 1000\n");
  fprintf(stderr, "     [ -n  1000000 ]    number of steps per run, default 10000\n");
  fprintf(stderr, "     [ -o output.txt ]  the output file, default: out.txt\n");
  fprintf(stderr, "     [ -f  100  ]       the intervel between steps in output data, default 100\n");
  fprintf(stderr, "      [ -g    1  ]   the paramater gamma, default: 1\n");
  fprintf(stderr, "      [ -d    1  ]   the paramater delta_t, default: 1\n");
  fprintf(stderr, "      [ -T    1  ]   the paramater kT, defualt: 1\n");
  fprintf(stderr, "     [ -h ]             display this information\n");
  fprintf(stderr, "\n");
  exit(1);
}

int main(int argc, char *argv[]) {

  srand(time(0));
  int ntime = 1000;
  int nstep = 10000;
  const char* filename = "out.txt";
  int inter = 100;
  char ch;
  while (( ch = getopt(argc, argv, "t:n:o:f:g:d:T:h")) != -1) {
    switch (ch) {
    case 't':
      ntime = atoi(optarg);
      break;
    case 'n':
      nstep = atoi(optarg);
      break;
    case 'o':
      filename = optarg;
      break;
    case 'f':
      inter = atoi(optarg);
      break;
    case 'g':
      status::gamma = atof(optarg);
      break;
    case 'd':
      status::delta_t = atof(optarg);
      break;
    case 'T':
      status::kT = atof(optarg);
      break;
    case 'h':
      usage(argv[0]);
    case '?':
      usage(argv[0]);
    }
  }


  float dist_s[nstep];
  for(int i = 0; i < nstep; ++i)
    dist_s[i] = 0;

  for(int i = 0; i < ntime; ++i) {
    status one;
    for(int j = 0; j < nstep; j++) {
      one.go();
      dist_s[j] += one.s.modulus();
    }
  }

  FILE* fp = fopen(filename, "w");
  for(int i = 0; i < nstep; ++i) {
    if(i % inter == 0) fprintf(fp, "%10d %12.2f\n", i, dist_s[i] / ntime);
  }
  fclose(fp);
}
