#include"status.h"

vec status::go() {
  gauss.initGauss();
  v = (-alpha * v + beta * gauss) * theta;
  s += v * delta_t;
  return s;
};
