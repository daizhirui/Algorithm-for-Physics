#include"vec.h"

int vec::nDim = 2;

unsigned seed = chrono::system_clock::now().time_since_epoch().count();
default_random_engine generator(seed);
normal_distribution<double> distribution;



void vec::setDim(int x) {
  if(x > nDim) {
    nDim = x;
    cout << "Dimension has been extended, please check and redefine all data to avoid potential erroneous value!" << endl;
  } else if(x < nDim) {
    nDim = x;
    cout << "Dimension has been shrinked, some data may be lost!" << endl;
  } else {
    cout << "Dimension has not been changed!" << endl;
  }
}

float vec::mmodulus() const {
  float m = 0.0;
  for(int i = 0; i < nDim; i++) {
    m += data[i] * data[i];
  }
  return m;
}
float vec::modulus() const {
  return sqrt(mmodulus());
}

void vec::reinitial() {
  vector<float> newd(nDim, 0.0);
  data = newd;
}
void vec::initGauss() {
  for(int i = 0; i < nDim; ++i) {
    data[i] = distribution(generator);
  }
}


vec vec::add(const vec& v) const {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = data[i] + v.data[i];
  }
  vec ne(newd);
  return ne;
}
vec vec::sub(const vec& v) const {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = data[i] - v.data[i];
  }
  vec ne(newd);
  return ne;
}
vec vec::mult(float x) const {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = data[i] * x;
  }
  vec ne(newd);
  return ne;
}

vec vec::div(float x) const {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = data[i] / x;
  }
  vec ne(newd);
  return ne;
}

float vec::dot(const vec& v) const {
  float m = 0.0;
  for(int i = 0; i < nDim; i++) {
    m += data[i] * v.data[i];
  }
  return m;
}

vec vec::cross(const vec& v) const {
  if(nDim != 3) {
    cerr << "The cross product is defined for 3 dimensional vectors!" << endl;
    exit(1);
  }
  vector<float> newd(nDim, 0.0);
  newd[0] = data[1] * v.data[2] - data[2] * v.data[1];
  newd[1] = data[2] * v.data[0] - data[0] * v.data[2];
  newd[2] = data[0] * v.data[1] - data[1] * v.data[0];
  vec ne(newd);
  return ne;
}
vec vec::setMag(float x) {
  float m = modulus();
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = data[i] * x / m;
  }
  data = newd;
  vec ne(data);
  return ne;
}
vec vec::normalize() {
  return setMag(1.0);
}
float vec::angleBetween(vec& v) const {
  float m = dot(v);
  float m1 = modulus();
  float m2 = v.modulus();
  return acos(m / m1 / m2);
}
float vec::dist(vec& v) const {
  vec ne;
  ne = sub(v);
  return ne.modulus();
}
vec vec::rotate(float x) {
  if(nDim != 2) {
    cerr << "The rotation is defined for 2 dimensional vectors!" << endl;
    exit(1);
  }
  vector<float> newd(nDim, 0.0);
  newd[0] = data[0] * cos(x) + data[1] * sin(x);
  newd[1] = -data[0] * sin(x) + data[1] * cos(x);
  vec ne(newd);
  *this = ne;
  return ne;
}

vec vec::random() {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = rand() * 1.0 / RAND_MAX;
  }
  data = newd;
  setMag(1.0);
  vec ne(data);
  return ne;
}
vec vec::random(float x) {
  vector<float> newd(nDim, 0.0);
  for(int i = 0; i < nDim; i++) {
    newd[i] = rand() * x / RAND_MAX;
  }
  data = newd;
  setMag(x);
  vec ne(data);
  return ne;
}

ostream& operator<<(ostream& os, const vec& v) {
  os << '(';
  for(int i = 0; i < v.Dim() - 1; i++) {
    os << v.getDim(i) << ',';
  }
  os << v.getDim(v.Dim() - 1) << ')';
  return os;
}
