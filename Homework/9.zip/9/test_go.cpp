#include"status.h"
float status::gamma = 1;
float status::delta_t = 1;
float status::kT = 1;


int main() {
  status one;
  one.m = 1;
  int i = 0;
  while(one.s.modulus() < 30) {
    one.go();
    i++;
    cout << i << ' ' << one.s << endl;
  }
}

