#ifndef VEC_H
#define VEC_H


#include<iostream>
#include<vector>
#include<cmath>
#include<random>
#include<chrono>

using namespace std;

class vec {
 private:
  static int nDim;
  vector<float> data;
 public:
  static void setDim(int);
  static int Dim() {
    return nDim;
  };

  float getDim(int x)const {
    return data[x];
  };

  vec() {
    vector<float> v(nDim, 0.0);
    data = v;
  };
  vec(float x) {
    vector<float> v(nDim, x);
    data = v;
  };
  vec(const vector<float>& v) {
    data = v;
  };
  void init(const vector<float>& v) {
    data = v;
  };

  float modulus() const;
  float mmodulus() const;

  void initGauss();
  void reinitial();

  vec add(const vec&) const;
  vec sub(const vec&) const;
  vec mult(float) const;
  vec div(float) const;
  float dot(const vec&) const;
  vec cross(const vec&) const;
  vec setMag(float);
  vec normalize();
  float angleBetween(vec&) const;
  float dist(vec&) const;
  vec rotate(float);
  vec random();
  vec random(float);

  float operator[](int i)const {
    return data[i];
  };

  vec operator+(const vec& v)const {
    return add(v);
  };
  vec operator-(const vec& v)const {
    return sub(v);
  };
  vec operator*(float x)const {
    return mult(x);
  };
  vec operator/(float x)const {
    return div(x);
  };
  vec operator+=(const vec& v) {
    vec ne = add(v);
    *this = ne;
    return ne;
  };
  vec operator-=(const vec& v) {
    vec ne = sub(v);
    *this = ne;
    return ne;
  };
  vec operator*=(float x) {
    vec ne = mult(x);
    *this = ne;
    return ne;
  };
  vec operator/=(float x) {
    vec ne = div(x);
    *this = ne;
    return ne;
  };
  friend vec operator*(float x, const vec& v) {
    return v.mult(x);
  };
  friend ostream& operator<<(ostream&, const vec&);
};

#endif
