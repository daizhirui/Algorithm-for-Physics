#ifndef STATUS_H
#define STATUS_H
#include"vec.h"

struct status {
  static float gamma, delta_t, kT;

  float m = 1;
  vec s;
  vec v;
  vec gauss;
  float alpha = m * gamma;
  float beta = sqrt(2 * alpha*kT / delta_t);
  float theta = 1 / (m * (1 + 0.5 * gamma*delta_t));

  vec go();
};

#endif
